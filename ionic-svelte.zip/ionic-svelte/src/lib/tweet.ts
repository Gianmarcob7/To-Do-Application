export default class Tweet {
    text: string
    constructor(text: string){
        this.text = text
    }
}