<script>
  import { onMount } from 'svelte';

  let cityInput = ''; 
  let weather = {
    city: 'City/Town Name',
    description: 'Loading...',
    temperature: '--°F',
    feels_like: '--°F',
    wind: '-- mph',
    humidity: '--%',
  };

  // Function to update weather data for a specific city
  async function getWeatherByCity(city) {
    const apiKey = '49f3e751085b6dca6998a65ae0c84a90';
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=imperial`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.cod === 200) {
        weather = {
          ...weather,
          city: data.name,
          description: data.weather[0].description,
          temperature: data.main.temp.toFixed(1),
          feels_like: data.main.feels_like.toFixed(1),
          wind: data.wind.speed.toFixed(1),
          humidity: data.main.humidity.toFixed(1),
        };
      } else {
        alert('City not found. Please try again.');
      }
    } catch (error) {
      console.error("Error fetching weather data: ", error);
    }
  }

  // Function to fetch weather data based on the user's current location
  async function getWeatherByLocation() {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const apiKey = '49f3e751085b6dca6998a65ae0c84a90';
      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&appid=${apiKey}&units=imperial`;

      try {
        const response = await fetch(url);
        const data = await response.json();

        weather = {
          ...weather,
          city: data.name,
          description: data.weather[0].description,
          temperature: data.main.temp.toFixed(1),
          feels_like: data.main.feels_like.toFixed(1),
          wind: data.wind.speed.toFixed(1),
          humidity: data.main.humidity.toFixed(1),
        };
      } catch (error) {
        console.error("Error fetching weather data: ", error);
      }
    });
  }

  onMount(() => {
    getWeatherByLocation(); // Fetch weather for the user's current location at load time
  });
</script>

<style>
   :global(body) {
    margin: 0;
    padding: 0;
  }
  
  .app-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center; 
    min-height: 100vh; 
    background-image: url('https://img.freepik.com/premium-photo/abstract-blurred-sky-colorful_40299-22.jpg'); 
    background-size: cover;
    background-position: center;
  }

  .weather-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 360px;
    padding: 20px;
    background-color: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  }
  
  .weather-details {
    text-align: center;
  }
  
  .city-name {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
  }
  
  .weather-description {
    font-size: 18px;
    color: #666;
    margin-bottom: 10px;
    text-align: center; 
  }
  
  .temperature {
    font-size: 36px;
    font-weight: bold;
    color: #365cf4;
    margin-bottom: 10px;
  }
  
  .additional-info p {
    font-size: 16px;
    color: #333;
    margin-bottom: 5px;
  }

  .small-button {
    --background: #3e70c7;
    --color: white;
    font-size: 18px; 
    padding: 10px 20px; 
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .small-button:hover {
    --background: #448AFF;
  }

  .smaller-search {
    flex: 1; 
    margin-right: 10px; 
    width: calc(100% - 100px);
  }

  .search-bar {
    display: flex;
    align-items: center;
  }

  .search-bar input[type="text"] {
    flex: 1;
    margin-right: 10px;
    width: calc(100% - 120px); 
  }

  .miniature-icon {
    width: 20px; 
    height: auto; 
    margin-right: 5px; 
  }
  

</style>

<ion-header>
  <ion-title>The Weather App (not channel)</ion-title>
</ion-header>

<div class="app-container">
  <div class="search-bar">
    <input type="text" bind:value={cityInput} placeholder="Enter city name" class="smaller-search" />
    <ion-button class="small-button" on:click={() => cityInput && getWeatherByCity(cityInput)} aria-roledescription="button">
      Search
    </ion-button>
  </div>

  <div class="weather-card">
    <div class="weather-details">
      <h1 class="city-name">{weather.city}</h1>
      <div class="weather-description">
        <p>Weather Description:</p>
        <p>{weather.description}</p>
      </div>
      <p class="temperature">Temperature: {weather.temperature}</p>
      <div class="additional-info">
        <p class="feels-like"><img src="https://static-00.iconduck.com/assets.00/temperature-feels-like-icon-495x512-ylzv705f.png" style="width: 20px;"> Feels Like: {weather.feels_like}</p>
        <p class="wind-info"><img src="https://static-00.iconduck.com/assets.00/wind-icon-2048x1570-qr102xee.png" style="width: 20px;"> Wind: {weather.wind}</p>
        <p class="humidity-info"><img src="https://cdn-icons-png.flaticon.com/512/219/219816.png" alt="Humidity Icon" style="width: 20px;"> Humidity: {weather.humidity}%</p>
      </div>
    </div>
  </div>
</div>
